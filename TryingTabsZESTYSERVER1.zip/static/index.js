const form = document.querySelector('form');
const urlinput = document.querySelector('form').elements.urlinput;
const name = document.querySelector('form').elements.name;
const pass = document.querySelector('form').elements.password;

form.addEventListener('submit', async event => {
  checkIfPassword()
});

function isUrl(val = '') {
  if (/^http(s?):\/\//.test(val) || val.includes('.') && val.substr(0, 1) !== ' ') return true;
  return false;
};

function serviceHappen() {
  event.preventDefault();
  window.navigator.serviceWorker.register('./sw.js', {
    scope: __uv$config.prefix
  }).then(() => {
    let url = urlinput.value.trim();
    if (!isUrl(url)) url = 'https://www.google.com/search?q=' + url;
    else if (!(url.startsWith('https://') || url.startsWith('http://'))) url = 'http://' + url;


    window.location.href = __uv$config.prefix + __uv$config.encodeUrl(url);
  });
}

//bozo ass script

//function gotoweb() {
//  var url = document.querySelector('form').elements.url.value;
//  if (url) {
//    serviceHappen('https://www.google.com/');
//  } else {
//    serviceHappen('http://',url);
//  }
//}

function checkIfPassword() {
  var pass = password.value;
  var user = name.value;

  if (user === 'max' && pass === 'games') {
    //serviceHappen()
    window.location.href = "./index.html"
  } else if (user === 'jake' && pass === 'because789') {
    serviceHappen()
  } else if (user === 'blake' && pass === '420') {
    serviceHappen()
  } else if (user === 'drake' && pass === 'king') {
    serviceHappen()
  } else if (user === 'wener' && pass === 'unbloker') {
    serviceHappen()
  } else if (user === 'mien' && pass === 'kampf') {
    serviceHappen()
  } else if (user === 'ohms' && pass === 'techteam') {
    serviceHappen()
  } else if (user === 'sickdawg' && pass === 'proplayer') {
    serviceHappen()
  } else if (user === 'bigchedda' && pass === 'bigchedda305') {
    serviceHappen()
  } else if (user === 'ShiftySmoothy' && pass === 'Gmoney') {
    serviceHappen()
  } else if (user === 'pp123' && pass === 'pp123') {
    serviceHappen()
  } else if (user === 'younggravy' && pass === 'yourmom') {
    serviceHappen()
  } else if (user === '20k.purplexed' && pass === 'purplexed') {
    serviceHappen()
  } else {
    alert('error code haha bozo', "username: ", user, "pass: ", pass);
  }
}

function Discord() {
  serviceHappen('https://discord.gg/pXZJw9BqXY');
}

const canvas = document.getElementById('canv');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
const ctx = canvas.getContext('2d');
let cols = Math.floor(window.innerWidth / 20) + 1;
let ypos = Array(cols).fill(0);

ctx.fillStyle = '#000';
ctx.fillRect(0, 0, canvas.width, canvas.height);

function matrix() {
  const w = window.innerWidth;
  const h = window.innerHeight;

  if (canvas.width !== w) {
    canvas.width = w;
    cols = Math.floor(window.innerWidth / 20) + 1;
    ypos = Array(cols).fill(0);
  }
  if (canvas.height !== h) {
    canvas.height = h;
  }

  ctx.fillStyle = '#0001';
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = '#0f0';
  ctx.font = '15pt monospace';

  ypos.forEach((y, ind) => {
    const text = String.fromCharCode(Math.random() * 128);
    const x = ind * 20;
    ctx.fillText(text, x, y);
    if (y > 100 + Math.random() * 10000) ypos[ind] = 0;
    else ypos[ind] = y + 20;
  });
}

setInterval(matrix, 50);
